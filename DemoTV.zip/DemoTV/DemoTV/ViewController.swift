//
//  ViewController.swift
//  DemoTV
//
//  Created by Conference on 6/19/17.
//
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

extension String {
    func localized() ->String {
        
        let selLang = appDelObj.currentLang
        let path = Bundle.main.path(forResource: selLang, ofType: "lproj")
        
        let bundle = Bundle(path: path!)
        return NSLocalizedString(self, tableName: nil, bundle: bundle!, value: "", comment: "")
    }
    func split(regexpattern: Character) -> [String] {
        
        return self.characters.split{$0 == regexpattern}.map(String.init)
    }
    
}


extension UIColor {
    
    func colorWithRGB(rgbValue : UInt, alpha : CGFloat = 1.0) -> UIColor {
        let red = CGFloat((rgbValue & 0xFF0000) >> 16) / 255
        let green = CGFloat((rgbValue & 0xFF00) >> 8) / 255
        let blue = CGFloat(rgbValue & 0xFF) / 255
        
        return UIColor(red: red, green: green, blue: blue, alpha: alpha)
    }
    
    class  func HexToColor(hexString: String, alpha:CGFloat? = 1.0) -> UIColor {
        // Convert hex string to an integer
        let hexint = Int(self.intFromHexString(hexStr: hexString))
        let red = CGFloat((hexint & 0xff0000) >> 16) / 255.0
        let green = CGFloat((hexint & 0xff00) >> 8) / 255.0
        let blue = CGFloat((hexint & 0xff) >> 0) / 255.0
        let alpha = alpha!
        // Create color object, specifying alpha as well
        let color = UIColor(red: red, green: green, blue: blue, alpha: alpha)
        return color
    }
    
    class func intFromHexString(hexStr: String) -> UInt32 {
        var hexInt: UInt32 = 0
        // Create scanner
        let scanner: Scanner = Scanner(string: hexStr)
        // Tell scanner to skip the # character
        scanner.charactersToBeSkipped = NSCharacterSet(charactersIn: "#") as CharacterSet
        // Scan hex value
        scanner.scanHexInt32(&hexInt)
        return hexInt
    }
    
    //MARK: helper methods
    class  func changeHexColorCodeToRGB(hex:UInt32, alpha: CGFloat) -> UIColor {
        
        return UIColor(   red: CGFloat((hex & 0xFF0000) >> 16)/255.0,
                          green: CGFloat((hex & 0xFF00) >> 8)/255.0,
                          blue: CGFloat((hex & 0xFF))/255.0,
                          alpha: alpha)
    }
    
}



import YNExpandableCell

class LAWorklistForDayVC: BaseViewController ,YNTableViewDelegate {
    
    
    @IBOutlet var lblHeading: UILabel!
    
    
    var expandableTableView: LUExpandableTableView = LUExpandableTableView()
    fileprivate let cellReuseIdentifier = "cell"
    fileprivate let sectionHeaderReuseIdentifier = "MySectionHeader"
    
    
    var hieght = 150
    var count = 0
    var cacheSelectedRows:[IndexPath]? = nil
    var callToCellAgain =  true
    
    var refreshCell:(() -> Void)? = nil
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        lblHeading.text = getLocalizedValue(forKey: "str_worklist_for_today", comment: "")
        
        view.addSubview(expandableTableView)
        expandableTableView.register(UINib(nibName: "WorkliTVCell", bundle: Bundle.main), forCellReuseIdentifier: cellReuseIdentifier)
        expandableTableView.register(UINib(nibName: "MyExpandableTableViewSectionHeader", bundle: Bundle.main), forHeaderFooterViewReuseIdentifier: sectionHeaderReuseIdentifier)
        expandableTableView.expandableTableViewDataSource = self
        expandableTableView.expandableTableViewDelegate = self
        
    }
    
    deinit {
    }
    
    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        
        expandableTableView.frame = view.bounds
        expandableTableView.frame.origin.y += 64
        expandableTableView.frame.origin.x += 16
        expandableTableView.frame.size.width = view.bounds.size.width - 32
        
        expandableTableView.backgroundColor = UIColor.white
        expandableTableView.separatorStyle = UITableViewCellSeparatorStyle.none
        expandableTableView.estimatedRowHeight = 150
        expandableTableView.rowHeight = UITableViewAutomaticDimension
        
    }
    
    //    MARK:
    //    MARK: Button Actions
    @IBAction func openLeftMenu(_ sender: Any) {
        self.showHideMenu()
    }
    
    @IBAction func messageBtnDidClicked(_ sender: Any) {
        
        let storyBoard = UIStoryboard.init(name: "VersionDesign_2", bundle: nil)
        let profileVc = storyBoard.instantiateViewController(withIdentifier: "LAMessageListVC") as! LAMessageListVC
        appDel.navigationController?.pushViewController(profileVc, animated: true)
        
    }
    
    
    //    MARK:
    //    MARK: TableView Delegate
    
    func tableView(_ tableView: YNTableView, expandCellWithHeightAt indexPath: IndexPath) -> YNTableViewCell? {
        let ynSliderCell = YNTableViewCell()
        ynSliderCell.cell = tableView.dequeueReusableCell(withIdentifier: WorklistItemCell.ID) as! WorklistItemCell
        ynSliderCell.height = 85
        
        return ynSliderCell
        
    }
    
    func tableView(_ tableView: YNTableView, expandCellAt indexPath: IndexPath) -> UITableViewCell? {
        let ynSliderCell = tableView.dequeueReusableCell(withIdentifier: WorklistItemCell.ID) as! WorklistItemCell
        //        count = count + 1
        
        return ynSliderCell
        
    }
    
    func updatecell() {
        
        DispatchQueue.main.async(execute:  {
            
            self.callToCellAgain =  false
            self.reloadRowsAtIndexPaths(self.expandableTableView,
                                        indexPath: IndexPath(row: 0, section: 0))
            
            self.expandableTableView.reloadData()
        })
    }
    
    func reloadRowsAtIndexPaths(_ tableView: UITableView, indexPath: IndexPath) {
        cacheSelectedRows = tableView.indexPathsForSelectedRows
        hieght = 240
        tableView.reloadRows(at: [indexPath], with: .fade)
        
        // Restore selection
        if let cacheSelectedRows = cacheSelectedRows {
            for path in cacheSelectedRows {
                tableView.selectRow(at: path, animated: false, scrollPosition: .none)
            }
        }
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let expandableCell = tableView.dequeueReusableCell(withIdentifier: YNExpandableCellEx.ID) as! YNExpandableCellEx
        if indexPath.section == 0 && indexPath.row == 0 {
            expandableCell.titleLabel.text = "Task 1"
        } else if indexPath.section == 0 && indexPath.row == 1 {
            expandableCell.titleLabel.text = "Task 2"
        } else if indexPath.section == 0 && indexPath.row == 2 {
            expandableCell.titleLabel.text = "Task 3"
        } else if indexPath.section == 1 && indexPath.row == 3 {
            expandableCell.titleLabel.text = "Task 1"
        } else {
            let nonExpandablecell = tableView.dequeueReusableCell(withIdentifier: "YNNonExpandableCell")
            nonExpandablecell?.textLabel?.text = " No Task "
            nonExpandablecell?.selectionStyle = .none
            return nonExpandablecell!
        }
        return expandableCell
        
    }
    
    func tableView(_ tableView: YNTableView, didSelectRowAt indexPath: IndexPath, isExpandableCell: Bool, isExpandedCell: Bool) {
        
        didSelectSubCell = true
        count = count + 1
        hieght = 150 + (count * 85)
        if let refreashcell = refreshCell {
            refreashcell()
        }
        let cell = tableView.cellForRow(at: indexPath) as?
        YNExpandableCellEx
        cell?.titleLabel.textColor = appGreenColor
        cell?.SeprtoreLineView.isHidden = true
        
        
        print("Selected Section: \(indexPath.section) Row: \(indexPath.row) isExpandableCell: \(isExpandableCell) isExpandedCell: \(isExpandedCell)")
    }
    
    func tableView(_ tableView: YNTableView, didDeselectRowAt indexPath: IndexPath, isExpandableCell: Bool, isExpandedCell: Bool) {
        print("Deselected Section: \(indexPath.section) Row: \(indexPath.row) isExpandableCell: \(isExpandableCell) isExpandedCell: \(isExpandedCell)")
        count = count - 1
        hieght = 150 + (count * 85)
        if let refreashcell = refreshCell {
            refreashcell()
        }
        let cell = tableView.cellForRow(at: indexPath) as? YNExpandableCellEx
        cell?.titleLabel.textColor = UIColor.lightGray
        cell?.SeprtoreLineView.isHidden = false
        
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 50
    }
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if section == 0 {
            return 3
        }
        
        return 0
    }
    
    
    
    
}

func  reloadCellInTBLview(_cell:YNExpandableCellEx)  {
    
    
}

// MARK: - LUExpandableTableViewDataSource

extension LAWorklistForDayVC: LUExpandableTableViewDataSource {
    func numberOfSections(in expandableTableView: LUExpandableTableView) -> Int {
        if expandableTableView.tag == 0 {
            return 3
        }
        else {
            return 1
        }
    }
    
    func expandableTableView(_ expandableTableView: LUExpandableTableView, numberOfRowsInSection section: Int) -> Int {
        if expandableTableView.tag == 0 {
            return 1
        }
        else {
            
            return 3
        }
    }
    
    func expandableTableView(_ expandableTableView: LUExpandableTableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell
    {
        
        guard let cell = expandableTableView.dequeueReusableCell(withIdentifier: "cell") as? WorkliTVCell
            
            else {
                
                assertionFailure("Cell shouldn't be nil")
                return UITableViewCell()
        }
        cell.TVCellHeightConstraint.constant = CGFloat(self.hieght)
        print(cell.TVCellHeightConstraint.constant)
        if (cell as? WorkliTVCell) != nil {
            refreshCell = {
                () -> Void in
                cell.TVCellHeightConstraint.constant = CGFloat(self.hieght)
                expandableTableView.beginUpdates()
                expandableTableView.endUpdates()
            }
        }
        
        cell.setCollectionViewDataSourceDelegate(self, forRow: indexPath.section)
        cell.clipsToBounds = true
        return cell
        
    }
    
    func expandableTableView(_ expandableTableView: LUExpandableTableView, sectionHeaderOfSection section: Int) -> LUExpandableTableViewSectionHeader {
        
        
        
        guard let sectionHeader = expandableTableView.dequeueReusableHeaderFooterView(withIdentifier: sectionHeaderReuseIdentifier) as? MyExpandableTableViewSectionHeader else
            
        {
            assertionFailure("Section header shouldn't be nil")
            return LUExpandableTableViewSectionHeader()
        }
        
        sectionHeader.label.text = "Section \(section)"
        return sectionHeader
        
        
    }
    
}

// MARK: - LUExpandableTableViewDelegate

extension LAWorklistForDayVC: LUExpandableTableViewDelegate {
    
    func expandableTableView(_ expandableTableView: LUExpandableTableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        /// Returning `UITableViewAutomaticDimension` value on iOS 9 will cause reloading all cells due to an iOS 9 bug with automatic dimensions
        return UITableViewAutomaticDimension
    }
    
    func expandableTableView(_ expandableTableView: LUExpandableTableView, heightForHeaderInSection section: Int) -> CGFloat {
        /// Returning `UITableViewAutomaticDimension` value on iOS 9 will cause reloading all cells due to an iOS 9 bug with automatic dimensions
        return 65
    }
    
    // MARK: - Optional
    
    func expandableTableView(_ expandableTableView: LUExpandableTableView, didSelectRowAt indexPath: IndexPath) {
        print("Did select cell at section \(indexPath.section) row \(indexPath.row)")
    }
    
    func expandableTableView(_ expandableTableView: LUExpandableTableView, didSelectSectionHeader sectionHeader: LUExpandableTableViewSectionHeader, atSection section: Int) {
        print("Did select section header at section \(section)")
    }
    
    func expandableTableView(_ expandableTableView: LUExpandableTableView, willDisplay cell: UITableViewCell, forRowAt indexPath: IndexPath) {
        print("Will display cell at section \(indexPath.section) row \(indexPath.row)")
        
    }
    
    func expandableTableView(_ expandableTableView: LUExpandableTableView, willDisplaySectionHeader sectionHeader: LUExpandableTableViewSectionHeader, forSection section: Int) {
        print("Will display section header for section \(section)")
        hieght = 150
        count = 0
    }
}

