//
//  LAAlertView.swift
//  LandscAPPer
//
//  Created by Conference on 6/14/17.
//  Copyright © 2017 Matellio LLC. All rights reserved.
//


/* How to use 
 
 let alertview = LAAlertView.instanceFromNib()
 
 alertview.openAlertView(title: "Hello", string: "his will be seen on tapping the “Detail” button on Home screen This will be the description detail of the task. The user will be able to dismiss the alert by tapping the “OK” button.")
 
 */

import UIKit

class LAAlertView: UIView {

    @IBOutlet weak var btnOk: UIButton!
    @IBOutlet weak var lblTital: UILabel!
    @IBOutlet weak var AlertView: UIView!
    @IBOutlet weak var txtView: UITextView!

    override func draw(_ rect: CGRect) {
        
        AlertView.layer.cornerRadius = 4
        AlertView.clipsToBounds = true
        
        btnOk.layer.cornerRadius = 4
        btnOk.clipsToBounds = true
        
        
        
    }
    
    class func instanceFromNib() -> LAAlertView {
        return UINib(nibName: "LAAlertView", bundle: nil).instantiate(withOwner: nil, options: nil)[0] as! LAAlertView
    }
    
    @IBAction func okBtnDidClicked(_ sender: Any) {
        
        removeAlertViewFromWindow()
        
        UIView.animate(withDuration: 0.4, delay: 0.0, options: .allowAnimatedContent, animations: {() -> Void in
            self.AlertView.transform = CGAffineTransform(scaleX: 0.1, y: 0.1)
            
        }, completion: {(finished: Bool) -> Void in
            self.AlertView.transform = CGAffineTransform.identity
            self.AlertView.transform = CGAffineTransform(scaleX: 0.0, y: 0.0)
            self.AlertView.isHidden = true
            self.AlertView.alpha = 0.0
            
            self.alpha = 0.5
        })
    }
    
    
    func removeAlertViewFromWindow()
    {
        for subview  in (appDel.window?.subviews)! {
            if subview.tag == 500500{
                subview.removeFromSuperview()
            }
        }
    }
    
    
    public func openAlertView(title:String , string : String ){
    
        lblTital.text  = title
        txtView.text  = string
        
        self.frame = CGRect(x: 0, y: 0, width: screenWidth, height: screenHeight)
        appDel.window!.addSubview(self)
        
        
        AlertView.alpha = 1.0
        AlertView.isHidden = false
       
        UIView.animate(withDuration: 0.2, animations: {() -> Void in
            self.alpha = 1.0
        })
        AlertView.transform = CGAffineTransform(scaleX: 0.0, y: 0.0)
        
        UIView.animate(withDuration: 0.3, delay: 0.2, options: .allowAnimatedContent, animations: {() -> Void in
            self.AlertView.transform = CGAffineTransform(scaleX: 1.1, y: 1.1)
           
        }, completion: {(finished: Bool) -> Void in
            UIView.animate(withDuration: 0.2, animations: {() -> Void in
                self.AlertView.transform = CGAffineTransform(scaleX: 1.0, y: 1.0)
               
            })
        })
    
    
    }
    
    
}
