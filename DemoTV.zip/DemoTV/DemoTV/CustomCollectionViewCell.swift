//
//  CustomCollectionViewCell.swift
//  LandscAPPer
//
//  Created by Matellio LLC on 2/17/17.
//  Copyright © 2017 Matellio LLC. All rights reserved.
//

import UIKit

class CustomCollectionViewCell: UICollectionViewCell {
    
    @IBOutlet var imageView: UIImageView!
    @IBOutlet weak var deleteButtonForDisplay: UIButton!
    @IBOutlet weak var deleteButtonForAction: UIButton!
}
