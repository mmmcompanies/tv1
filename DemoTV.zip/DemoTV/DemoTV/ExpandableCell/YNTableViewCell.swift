//
//  YNTableViewCell.swift
//  YNExpandableCell
//
//  Created by YiSeungyoun on 2017. 4. 8..
//  Copyright © 2017년 SeungyounYi. All rights reserved.
//

import UIKit

open class YNTableViewCell: NSObject {
    open var cell: UITableViewCell?
    open var height: CGFloat?
}
