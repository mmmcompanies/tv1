//
//  CustomHeaderCell.swift
//  Sware
//
//  Created by Matellio LLC on 10/7/16.
//  Copyright © 2016 CGT. All rights reserved.
//

import UIKit

class CustomHeaderCell: UITableViewHeaderFooterView {
 
    @IBOutlet var lblTaskTitle: UILabel!
    @IBOutlet var lblAssignedHours: UILabel!
    @IBOutlet var lblUsedHours: UILabel!
    
    @IBOutlet var btnMaterials: UIButton!
    @IBOutlet var btnPhotos: UIButton!
    required internal init?(coder aDecoder: NSCoder)
    {
        super.init(coder: aDecoder)
//        self.frame = CGRectMake(0, 0, UIScreen.main.bounds.size.width, 30)
    }

   
    // Only override drawRect: if you perform custom drawing.
    // An empty implementation adversely affects performance during animation.
    override func draw(_ rect: CGRect) {
        // Drawing code
        
    }
 
    
}
