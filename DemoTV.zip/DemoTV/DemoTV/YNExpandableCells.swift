//
//  YNExpandableCells.swift
//  YNExpandableCell
//
//  Created by YiSeungyoun on 2017. 3. 14..
//  Copyright © 2017년 SeungyounYi. All rights reserved.
//

import YNExpandableCell
import UIKit

class YNExpandableCellEx: YNExpandableCell {
    static let ID = "YNExpandableCellEx"
    
    @IBOutlet var titleLabel: UILabel!
    @IBOutlet weak var SeprtoreLineView: UIView!

    public override init(style: UITableViewCellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
    }
    
    required public init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        
    }
    
    public override func awakeFromNib() {
        super.awakeFromNib()
        
    }
}

class WorkliTVCell: UITableViewCell {
    static let ID = "WorkliTVCell"
   
    
    @IBOutlet weak var TVCellHeightConstraint: NSLayoutConstraint!
    @IBOutlet weak var ynTableView: YNTableView!
    public override init(style: UITableViewCellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        
    }
    
    required public init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
    }
    
    public override func awakeFromNib() {
        super.awakeFromNib()
        self.selectionStyle = .none
        
        self.layer.borderColor = UIColor(red: 236/255, green: 236/255, blue: 236/255, alpha: 1.0).cgColor
        self.layer.borderWidth = 1
        self.clipsToBounds = true
        
        
//        self.ynTableView.registerCellsWith(cells: [UITableViewCell.self as AnyClass], and: ["YNNonExpandableCell"])
        
        ynTableView.register(UINib(nibName: "YNExpandableCellEx", bundle: Bundle.main), forCellReuseIdentifier: "YNExpandableCellEx")
        ynTableView.register(UINib(nibName: "WorklistItemCell", bundle: Bundle.main), forCellReuseIdentifier: "WorklistItemCell")
        
        ynTableView.ynTableViewRowAnimation = .top
        
        NotificationCenter.default.addObserver(self, selector: #selector(self.collapseAllCell(_:)), name: NSNotification.Name(rawValue: "collapseAll"), object: nil)
        
    }
    
    func collapseAllCell(_ notification: NSNotification) {
        ynTableView.collapseAll()
    }
    
}

extension WorkliTVCell {
    
    func setCollectionViewDataSourceDelegate<D: YNTableViewDelegate>(_ dataSourceDelegate: D, forRow row: Int) {
        
        ynTableView.ynDelegate = dataSourceDelegate
        ynTableView.reloadData()
    }
}

class WorklistItemCell: UITableViewCell {
    static let ID = "WorklistItemCell"
    
    public override init(style: UITableViewCellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        
    }
    
    required public init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
    }
    
    public override func awakeFromNib() {
        super.awakeFromNib()
        self.selectionStyle = .none

    }

}
    class CrewMemberTVCell: UITableViewCell {
        static let ID = "CrewMemberTVCell"
        
        public override init(style: UITableViewCellStyle, reuseIdentifier: String?) {
            super.init(style: style, reuseIdentifier: reuseIdentifier)
            
        }
        
        required public init?(coder aDecoder: NSCoder) {
            super.init(coder: aDecoder)
        }
        
        public override func awakeFromNib() {
            super.awakeFromNib()
            self.selectionStyle = .none
            
        }

}
