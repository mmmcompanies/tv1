//
//  CustomCell.swift
//  LandscAPPer
//
//  Created by Matellio LLC on 2/2/17.
//  Copyright © 2017 Matellio LLC. All rights reserved.
//

import UIKit

public enum CollectionViewStyle: Int {
    case forPhotos = 0
    case forPlans = 1
}

class CustomCell: MGSwipeTableCell, UICollectionViewDelegate, UICollectionViewDataSource{
   

    @IBOutlet var lineImage: UIImageView!
    @IBOutlet var bottomImage: UIImageView!
    @IBOutlet var topImage: UIImageView!
    @IBOutlet var imgMenuOption: UIImageView!
    @IBOutlet var lblMenuOption: UILabel!
    @IBOutlet var imageColletionView: UICollectionView!
    let layout: UICollectionViewFlowLayout = UICollectionViewFlowLayout()

    @IBOutlet var lblTotalTime: UILabel!
    @IBOutlet var lblClockOutTime: UILabel!
    @IBOutlet var lblClockInTime: UILabel!
    @IBOutlet weak var clockTimeHeightConstraint: NSLayoutConstraint!
    @IBOutlet weak var clockTimeTopConstraint: NSLayoutConstraint!
    
    
    @IBOutlet var textField: UITextField!
    @IBOutlet var checkButton: UIButton!
    @IBOutlet var lbldescription: UILabel!
    @IBOutlet var lblTime: UILabel!
    @IBOutlet var lblTitle: UILabel!
    @IBOutlet var imgView: UIImageView!
    @IBOutlet var btnIncrement: UIButton!
    @IBOutlet var btnDecrement: UIButton!
    
    @IBOutlet weak var messageContainerView: UIView!
    @IBOutlet weak var separatorViewSideMenuCell: UIView!
    
    @IBOutlet var checkButton_MC: UIButton!
    @IBOutlet var lblMetrial: UILabel!
    @IBOutlet var lblQuntity: UILabel!
    
    var isDeleteButtonHidden = false
    
    var photoObjArray = [LAPhotoObject]()
    var plansObjArray = [LAPlans]()

    var collectionViewStyle: CollectionViewStyle! = .forPhotos
    
    override func awakeFromNib() {
        super.awakeFromNib()
        if (imageColletionView != nil){
            imageColletionView.delegate = self
            imageColletionView!.setCollectionViewLayout(layout, animated: true);
            layout.sectionInset = UIEdgeInsets(top:10, left:10, bottom: 10, right:10)
            layout.itemSize = CGSize(width: (UIScreen.main.bounds.size.width/3)-15, height: (UIScreen.main.bounds.size.width/3)-15)
        }
       
        // Initialization code
    }
    
    func initializeCollectionView(withCollectionViewStyle: CollectionViewStyle, photoArray:[AnyObject], deleteButtonHidden:Bool) {
        
        collectionViewStyle = withCollectionViewStyle
        
        if collectionViewStyle == CollectionViewStyle.forPhotos {
            photoObjArray = photoArray as! [LAPhotoObject]
        } else if collectionViewStyle == CollectionViewStyle.forPlans {
            plansObjArray = photoArray as! [LAPlans]
        }
        imageColletionView.reloadData()
        isDeleteButtonHidden = deleteButtonHidden
    }
    
    func numberOfSectionsInCollectionView(collectionView: UICollectionView) -> Int {
        return 1
    }
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        
        if collectionViewStyle == CollectionViewStyle.forPhotos {
            if photoObjArray.count > 0
            {
                imageColletionView.backgroundView = nil
            }
            else
            {
                showFillerLabel()
            }
            
            return photoObjArray.count
        } else if collectionViewStyle == CollectionViewStyle.forPlans {
            if plansObjArray.count > 0
            {
                imageColletionView.backgroundView = nil
            }
            else
            {
                showFillerLabel()
            }
            
            return plansObjArray.count
        }
        
        return 1
    }
    
    public  func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell : CustomCollectionViewCell = collectionView.dequeueReusableCell(withReuseIdentifier: "CustomCollectionViewCell", for: indexPath as IndexPath) as! CustomCollectionViewCell
        
        if collectionViewStyle == CollectionViewStyle.forPhotos {
            
            let obj:LAPhotoObject = photoObjArray[indexPath.row]
            let url = URL(string: obj.photo_image!)
            if (obj.photo_id == nil || obj.photo_id == "") {
                cell.imageView.image = getImage(path: (obj.photo_image)!)
//                print(obj.photo_image)
            }
            else{
                cell.imageView.kf_setImage(with: url)
            }
        } else if collectionViewStyle == CollectionViewStyle.forPlans {
            
            let obj:LAPlans = plansObjArray[indexPath.row]
//            cell.imageView.image = getImage(path: (obj.plan_file)!)
            let planURL = URL(string: obj.plan_file!)

            cell.imageView.kf_setImage(with: planURL)
//            print(obj.plan_file)
        }

        cell.imageView.layer.cornerRadius = 5.0
        cell.imageView.layer.masksToBounds=true
        
        cell.deleteButtonForDisplay.isHidden = isDeleteButtonHidden
        cell.deleteButtonForAction.isHidden = isDeleteButtonHidden
        
        return cell
    }
    func showFillerLabel()
    {
        let noDataLabel: UILabel     = UILabel(frame: CGRect(x:0, y:0, width:imageColletionView.bounds.size.width, height:imageColletionView.bounds.size.height))
        noDataLabel.font             = UIFont(name: "Gotham-Light", size: 17.0)
        noDataLabel.text             = "No photo added!"
        noDataLabel.textColor        = UIColor.black
        noDataLabel.textAlignment    = .center
        imageColletionView.backgroundView = noDataLabel
    }
    
    func collectionView(collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumInteritemSpacingForSectionAtIndex section: Int) -> CGFloat {
        return 0
    }
    
    func collectionView(collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumLineSpacingForSectionAtIndex section: Int) -> CGFloat {
        return 0
    }
    
    func collectionView(collectionView: UICollectionView, didSelectItemAtIndexPath indexPath: NSIndexPath)
    {
//        let cell = imageColletionView.cellForItem(at: indexPath as IndexPath) as! CustomCollectionViewCell
//        let obj:PhotoObject = photoObjArray[indexPath.row]
       
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
